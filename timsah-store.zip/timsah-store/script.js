"use strict";

/* ==========================================================================
   CONFIG — ضع بياناتك هنا
   ========================================================================== */
const CONFIG = {
  // Meta Pixel: استبدل بالـ Pixel ID بتاعك من Facebook Events Manager
  META_PIXEL_ID: "2000297770639692",
  // Google Analytics 4: استبدل بالـ Measurement ID بتاعك (يبدأ بـ G-)
  GA4_MEASUREMENT_ID: "YOUR_GA4_MEASUREMENT_ID",
  // EmailJS: من https://www.emailjs.com/
  EMAILJS_PUBLIC_KEY: "ie3Qvb22skf_NsELL",
  EMAILJS_SERVICE_ID: "service_ugb0k6v",
  EMAILJS_TEMPLATE_ID: "template_cxujxdk",
  PRODUCT_PRICE: 349,
  SHIPPING_CAIRO_GIZA: 70,
  SHIPPING_OTHER: 90,
  WHATSAPP_NUMBER: "201000000000"
};

/* ==========================================================================
   Tracking helpers — لن تعمل فعليًا حتى تضيف الـ IDs الحقيقية فوق
   ========================================================================== */
function trackEvent(pixelName, ga4Name, params) {
  try {
    if (window.fbq && CONFIG.META_PIXEL_ID !== "") {
      window.fbq("track", pixelName, params || {});
    }
    if (window.gtag && CONFIG.GA4_MEASUREMENT_ID !== "YOUR_GA4_MEASUREMENT_ID") {
      window.gtag("event", ga4Name, params || {});
    }
  } catch (e) {
    console.warn("Tracking error:", e);
  }
}

document.addEventListener("DOMContentLoaded", () => {
  // ملاحظة: PageView بيتبعت أوتوماتيك من كود البيكسل الأساسي في <head>، فمش بنكرره هنا
  if (window.gtag && CONFIG.GA4_MEASUREMENT_ID !== "YOUR_GA4_MEASUREMENT_ID") {
    window.gtag("event", "page_view", {});
  }
  trackEvent("ViewContent", "view_item", {
    content_name: "قميص الأهلي 2027",
    value: CONFIG.PRODUCT_PRICE,
    currency: "EGP"
  });
});

/* ==========================================================================
   Header scroll state
   ========================================================================== */
const header = document.getElementById("header");
window.addEventListener("scroll", () => {
  header.classList.toggle("is-scrolled", window.scrollY > 40);
}, { passive: true });

/* ==========================================================================
   Mobile menu
   ========================================================================== */
const burgerBtn = document.getElementById("burgerBtn");
const mobileMenu = document.getElementById("mobileMenu");
const mobileMenuClose = document.getElementById("mobileMenuClose");

function openMobileMenu() { mobileMenu.classList.add("is-open"); }
function closeMobileMenu() { mobileMenu.classList.remove("is-open"); }

burgerBtn.addEventListener("click", openMobileMenu);
mobileMenuClose.addEventListener("click", closeMobileMenu);
mobileMenu.addEventListener("click", (e) => { if (e.target === mobileMenu) closeMobileMenu(); });
mobileMenu.querySelectorAll("a").forEach(a => a.addEventListener("click", closeMobileMenu));

/* ==========================================================================
   Scroll reveal system (IntersectionObserver)
   ========================================================================== */
const revealTargets = document.querySelectorAll(
  ".reveal, .reveal-left, .reveal-right, .reveal-scale, .stagger-item"
);

const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry, i) => {
    if (entry.isIntersecting) {
      const el = entry.target;
      const group = el.parentElement;
      if (el.classList.contains("stagger-item") && group) {
        const siblings = Array.from(group.children).filter(c => c.classList.contains("stagger-item"));
        const idx = siblings.indexOf(el);
        el.style.transitionDelay = `${Math.min(idx, 8) * 70}ms`;
      }
      el.classList.add("is-visible");
      revealObserver.unobserve(el);
    }
  });
}, { threshold: 0.15, rootMargin: "0px 0px -40px 0px" });

revealTargets.forEach(el => revealObserver.observe(el));

/* ==========================================================================
   Product gallery
   ========================================================================== */
const galleryThumbs = document.querySelectorAll(".gallery-thumb");
const galleryImgs = document.querySelectorAll(".gallery-main img");

galleryThumbs.forEach(thumb => {
  thumb.addEventListener("click", () => {
    const target = thumb.getAttribute("data-img");
    galleryThumbs.forEach(t => t.classList.remove("is-active"));
    thumb.classList.add("is-active");
    galleryImgs.forEach(img => {
      img.classList.toggle("is-active", img.getAttribute("src") === target);
    });
  });
});

/* ==========================================================================
   Size selection (product section)
   ========================================================================== */
let selectedSize = "L";
const sizeOpts = document.querySelectorAll(".size-opt");
const sizeConfirmSelect = document.getElementById("sizeConfirm");

sizeOpts.forEach(opt => {
  opt.addEventListener("click", () => {
    sizeOpts.forEach(o => o.classList.remove("is-selected"));
    opt.classList.add("is-selected");
    selectedSize = opt.getAttribute("data-size");
    if (sizeConfirmSelect) sizeConfirmSelect.value = selectedSize;
  });
});

/* ==========================================================================
   Size calculator
   ========================================================================== */
const calcBtn = document.getElementById("calcBtn");
const calcResult = document.getElementById("calcResult");
const calcHeight = document.getElementById("calcHeight");
const calcWeight = document.getElementById("calcWeight");

function suggestSize(heightCm, weightKg) {
  // تقريب بسيط لجدول المقاسات المعروض في الصفحة
  if (heightCm < 168 || weightKg < 62) return "S";
  if (heightCm < 175 || weightKg < 72) return "M";
  if (heightCm < 182 || weightKg < 85) return "L";
  if (heightCm < 188 || weightKg < 98) return "XL";
  return "XXL";
}

calcBtn.addEventListener("click", () => {
  const h = parseFloat(calcHeight.value);
  const w = parseFloat(calcWeight.value);
  if (!h || !w) {
    calcResult.innerHTML = `<span style="color:var(--red);font-size:14px;">من فضلك ادخل الطول والوزن بشكل صحيح</span>`;
    return;
  }
  calcResult.innerHTML = `<div class="calc-loading"><span></span><span></span><span></span></div>`;
  setTimeout(() => {
    const size = suggestSize(h, w);
    calcResult.innerHTML = `
      <span style="font-size:13.5px;color:var(--text-on-light-dim);">المقاس المقترح</span>
      <span class="calc-result-value">${size}</span>
    `;
    requestAnimationFrame(() => {
      calcResult.querySelector(".calc-result-value").classList.add("is-shown");
    });
    // مزامنة المقاس المقترح مع اختيار المنتج
    sizeOpts.forEach(o => o.classList.toggle("is-selected", o.getAttribute("data-size") === size));
    selectedSize = size;
    if (sizeConfirmSelect) sizeConfirmSelect.value = size;
  }, 480);
});

const sizeChartToggle = document.getElementById("sizeChartToggle");
const sizeChart = document.getElementById("sizeChart");
sizeChartToggle.addEventListener("click", () => {
  sizeChartToggle.classList.toggle("is-open");
  sizeChart.classList.toggle("is-open");
});

/* ==========================================================================
   FAQ accordion
   ========================================================================== */
document.querySelectorAll(".faq-item").forEach(item => {
  const q = item.querySelector(".faq-q");
  const a = item.querySelector(".faq-a");
  q.setAttribute("aria-expanded", "false");
  q.addEventListener("click", () => {
    const isOpen = item.classList.contains("is-open");
    document.querySelectorAll(".faq-item").forEach(other => {
      other.classList.remove("is-open");
      other.querySelector(".faq-a").style.maxHeight = null;
      other.querySelector(".faq-q").setAttribute("aria-expanded", "false");
    });
    if (!isOpen) {
      item.classList.add("is-open");
      a.style.maxHeight = a.scrollHeight + "px";
      q.setAttribute("aria-expanded", "true");
    }
  });
});

/* ==========================================================================
   Sticky mobile CTA
   ========================================================================== */
const stickyCta = document.getElementById("stickyCta");
const heroEl = document.querySelector(".hero");

window.addEventListener("scroll", () => {
  const heroBottom = heroEl.getBoundingClientRect().bottom;
  stickyCta.classList.toggle("is-visible", heroBottom < 0);
}, { passive: true });

/* ==========================================================================
   Checkout drawer flow
   ========================================================================== */
const checkoutOverlay = document.getElementById("checkoutOverlay");
const drawerClose = document.getElementById("drawerClose");
const checkoutForm = document.getElementById("checkoutForm");
const reviewStep = document.getElementById("reviewStep");
const loadingStep = document.getElementById("loadingStep");
const successStep = document.getElementById("successStep");
const errorStep = document.getElementById("errorStep");
const confirmOrderBtn = document.getElementById("confirmOrderBtn");
const backToFormBtn = document.getElementById("backToFormBtn");
const retryOrderBtn = document.getElementById("retryOrderBtn");

let isSubmitting = false;
let lastOrderPayload = null;

function openCheckout() {
  checkoutOverlay.classList.add("is-open");
  stickyCta.classList.add("is-hidden-checkout");
  document.body.style.overflow = "hidden";
  trackEvent("InitiateCheckout", "begin_checkout", {
    value: CONFIG.PRODUCT_PRICE,
    currency: "EGP"
  });
  goToStep(checkoutForm);
}
function closeCheckout() {
  checkoutOverlay.classList.remove("is-open");
  stickyCta.classList.remove("is-hidden-checkout");
  document.body.style.overflow = "";
}

document.querySelectorAll(".js-open-checkout").forEach(btn => {
  btn.addEventListener("click", (e) => {
    e.preventDefault();
    trackEvent("buttonClick", "select_item", { content_name: "اطلب دلوقتي" });
    openCheckout();
  });
});
drawerClose.addEventListener("click", closeCheckout);
checkoutOverlay.addEventListener("click", (e) => { if (e.target === checkoutOverlay) closeCheckout(); });

function goToStep(stepEl) {
  [checkoutForm, reviewStep, loadingStep, successStep, errorStep].forEach(s => s.classList.remove("is-active"));
  stepEl.classList.add("is-active");
}

/* ---- Form validation ---- */
function validateField(id, condition) {
  const wrap = document.getElementById(id);
  wrap.classList.toggle("has-error", !condition);
  return condition;
}

checkoutForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const fullName = document.getElementById("fullName").value.trim();
  const phone = document.getElementById("phone").value.trim();
  const gov = document.getElementById("gov").value.trim();
  const city = document.getElementById("city").value.trim();
  const address = document.getElementById("address").value.trim();

  const validName = validateField("fName", fullName.length >= 3);
  const validPhone = validateField("fPhone", /^01[0125][0-9]{8}$/.test(phone));
  const validGov = validateField("fGov", gov.length >= 2);
  const validCity = validateField("fCity", city.length >= 2);
  const validAddress = validateField("fAddress", address.length >= 6);

  if (!(validName && validPhone && validGov && validCity && validAddress)) {
    return;
  }

  const isCairoGiza = /قاهرة|جيزة|Cairo|Giza/i.test(gov);
  const shippingCost = isCairoGiza ? CONFIG.SHIPPING_CAIRO_GIZA : CONFIG.SHIPPING_OTHER;
  const total = CONFIG.PRODUCT_PRICE + shippingCost;

  lastOrderPayload = {
    fullName, phone, gov, city, address,
    size: selectedSize,
    price: CONFIG.PRODUCT_PRICE,
    shipping: shippingCost,
    total,
    paymentMethod: "الدفع عند الاستلام",
    product: "قميص الأهلي 2027",
    timestamp: new Date().toISOString()
  };

  document.getElementById("rvSize").textContent = selectedSize;
  document.getElementById("rvName").textContent = fullName;
  document.getElementById("rvAddress").textContent = `${address}, ${city}, ${gov}`;
  document.getElementById("rvShip").textContent = `${shippingCost} ج.م`;
  document.getElementById("rvTotal").textContent = `${total} ج.م`;

  goToStep(reviewStep);
});

backToFormBtn.addEventListener("click", () => goToStep(checkoutForm));

/* ---- Order submission (EmailJS) ---- */
function generateOrderId() {
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `TS-${rand}`;
}

async function submitOrder() {
  if (isSubmitting || !lastOrderPayload) return;
  isSubmitting = true;
  confirmOrderBtn.setAttribute("disabled", "true");
  goToStep(loadingStep);

  const orderId = generateOrderId();

  try {
    // إرسال الطلب عبر EmailJS — يتطلب إضافة الـ IDs الحقيقية في CONFIG أعلى الملف
    if (window.emailjs) {
      await window.emailjs.send(
        CONFIG.EMAILJS_SERVICE_ID,
        CONFIG.EMAILJS_TEMPLATE_ID,
        { ...lastOrderPayload, orderId }
      );
    } else {
      // لا يوجد EmailJS مُهيأ بعد: هذا الجزء فقط بديل مؤقت لعرض التدفق
      // أضف بيانات EmailJS الحقيقية في CONFIG لتفعيل الإرسال الفعلي
      await new Promise((resolve) => setTimeout(resolve, 900));
    }

    document.getElementById("orderIdBox").textContent = `رقم الطلب: #${orderId}`;
    goToStep(successStep);

    trackEvent("Purchase", "purchase", {
      value: lastOrderPayload.total,
      currency: "EGP",
      transaction_id: orderId
    });

  } catch (err) {
    console.error("Order submission failed:", err);
    goToStep(errorStep);
  } finally {
    isSubmitting = false;
    confirmOrderBtn.removeAttribute("disabled");
  }
}

confirmOrderBtn.addEventListener("click", submitOrder);
retryOrderBtn.addEventListener("click", submitOrder);

/* Prevent closing the drawer by clicking outside while an order is submitting */
checkoutOverlay.addEventListener("click", (e) => {
  if (e.target === checkoutOverlay && isSubmitting) e.stopImmediatePropagation();
}, true);

/* Reset drawer to step 1 whenever it's reopened */
document.querySelectorAll(".js-open-checkout").forEach(btn => {
  btn.addEventListener("click", () => {
    if (!isSubmitting) goToStep(checkoutForm);
  });
});
